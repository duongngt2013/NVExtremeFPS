package com.nvfps;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;

/**
 * NV Extreme FPS v0.1.0.
 * Keeps Render Distance at 6+ and removes several expensive visual effects
 * when FPS becomes critically low. Client-side only.
 */
public final class NVExtremeFPSClient implements ClientModInitializer {
    private static final int MIN_RENDER_DISTANCE = 6;
    private static final int LOW_FPS = 18;
    private static int tickCounter;
    private static boolean lowMode;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(NVExtremeFPSClient::tick);
    }

    private static void tick(MinecraftClient client) {
        if (client == null || client.options == null || client.world == null) return;
        if (++tickCounter < 20) return;
        tickCounter = 0;

        GameOptions options = client.options;
        if (options.getViewDistance().getValue() < MIN_RENDER_DISTANCE) {
            options.getViewDistance().setValue(MIN_RENDER_DISTANCE);
        }

        int fps = client.getCurrentFps();
        if (!lowMode && fps > 0 && fps <= LOW_FPS) {
            options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            options.getEntityShadows().setValue(false);
            options.getParticles().setValue(ParticlesMode.MINIMAL);
            options.getBiomeBlendRadius().setValue(0);
            lowMode = true;
        }
    }
}
