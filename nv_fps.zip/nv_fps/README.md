# NV Extreme FPS — Fabric 1.21.11

Bản source đầu tiên, thiết kế cho máy cực yếu và mục tiêu giữ **ít nhất 6 chunk**.

## Có gì trong v0.1.0

- Fabric Loader 0.19.5+
- Minecraft Java 1.21.11
- Fabric API 0.141.6+1.21.11
- Java 21
- Không ép Render Distance xuống dưới 6 chunk.
- Khi FPS <= 18, tự tắt cloud, entity shadows, giảm particles và biome blend về 0.
- Không thay đổi gameplay, combat hay server.

## Build

Trên PC có Java 21 và Gradle:

    gradle build

JAR nằm trong `build/libs/`.

## Lưu ý

Đây là bản nền để benchmark, chưa hứa một mức FPS cụ thể. Sau khi có kết quả thực tế trên máy, có thể tối ưu sâu hơn vào chunk renderer/entity/GPU bottleneck thay vì đoán.

Fabric xác nhận Minecraft 1.21.11 là bản 1.x obfuscated cuối; với 1.21.11 trở xuống, Fabric Loom dùng plugin `fabric-loom-remap`.
